package br.com.southrocklab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QaTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(QaTestApplication.class, args);
	}

}
