package br.com.southrocklab.domain;

import io.swagger.annotations.ApiModel;

@ApiModel
public enum Brand {
    MASTER,
    VISA,
    ELO;
}
